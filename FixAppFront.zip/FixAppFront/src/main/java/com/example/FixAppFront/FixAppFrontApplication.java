package com.example.FixAppFront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FixAppFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(FixAppFrontApplication.class, args);
	}

}
