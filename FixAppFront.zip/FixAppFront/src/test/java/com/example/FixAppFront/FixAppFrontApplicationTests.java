package com.example.FixAppFront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixAppFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
